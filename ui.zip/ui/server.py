from flask import Flask, request, jsonify
from flask_cors import CORS
import io
import os

try:
    from PyPDF2 import PdfReader
except Exception:
    PdfReader = None

try:
    import docx  # python-docx
except Exception:
    docx = None

app = Flask(__name__)
CORS(app)  # Allow requests from file:// or any origin for this prototype


def read_txt(file_stream: io.BytesIO) -> str:
    try:
        return file_stream.read().decode("utf-8", errors="ignore")
    except Exception:
        try:
            file_stream.seek(0)
            return file_stream.read().decode("latin-1", errors="ignore")
        except Exception:
            return ""


def read_pdf(file_stream: io.BytesIO) -> str:
    if not PdfReader:
        return ""
    try:
        reader = PdfReader(file_stream)
        parts = []
        for page in reader.pages:
            try:
                parts.append(page.extract_text() or "")
            except Exception:
                continue
        return "\n".join(parts)
    except Exception:
        return ""


def read_docx(file_stream: io.BytesIO) -> str:
    if not docx:
        return ""
    try:
        file_stream.seek(0)
        document = docx.Document(file_stream)
        return "\n".join(p.text for p in document.paragraphs)
    except Exception:
        return ""


def ats_suggestions_for(text: str) -> list:
    suggestions = []
    if len(text) < 800:
        suggestions.append("Resume seems short; expand with quantified achievements and skills.")
    if "experience" not in text.lower():
        suggestions.append("Add an Experience section header for ATS parsing.")
    if "%" not in text:
        suggestions.append("Quantify impact (%, time saved, cost reduced, revenue grown).")
    return suggestions


def summarize_brief(text: str) -> str:
    """Heuristic brief summary: extract 2-3 impactful sentences/lines."""
    if not text:
        return ""
    import re
    # Normalize whitespace and split into sentences (very naive)
    clean = re.sub(r"\s+", " ", text).strip()
    # Prefer bullet lines and impact cues from original text as well
    lines = [l.strip() for l in (text.splitlines()[:60]) if l.strip()]
    cues = [
        r"increas|improv|reduc|optim|deliver|scal|lead|own|mentor|migrat|design|architect|build",
        r"%|\bKPI\b|OKR|revenue|latency|throughput|cost|users|traffic|availability|SLA|SLO",
    ]
    scored = []
    for l in lines:
        score = 0
        if l.startswith(('-', '•', '*')):
            score += 1
        low = l.lower()
        for pat in cues:
            if re.search(pat, low):
                score += 1
        scored.append((score, l))
    # Take top 2-3 lines by score; fallback to first sentences
    scored.sort(key=lambda x: x[0], reverse=True)
    chosen = [l for s, l in scored[:3] if s > 0]
    if not chosen:
        # fallback: first 2 sentences from clean
        sentences = re.split(r"(?<=[\.!?])\s+", clean)
        chosen = sentences[:2]
    brief = " ".join(chosen).strip()
    return brief[:600]


def analyze_locally(raw_text: str, role: str) -> dict:
    role_keywords = {
        'Frontend Developer': ['react', 'javascript', 'typescript', 'css', 'html', 'redux', 'vite', 'webpack', 'tailwind', 'ui', 'accessibility'],
        'Backend Developer': ['node', 'express', 'nestjs', 'api', 'database', 'sql', 'postgres', 'mongodb', 'redis', 'queues', 'auth'],
        'Full‑Stack Engineer': ['frontend', 'backend', 'react', 'node', 'api', 'docker', 'cloud', 'testing', 'ci', 'typescript'],
        'Data Scientist': ['python', 'pandas', 'numpy', 'scikit', 'machine learning', 'statistics', 'model', 'experiment', 'visualization', 'jupyter'],
        'ML Engineer': ['pytorch', 'tensorflow', 'mlops', 'inference', 'training', 'pipeline', 'feature store', 'deployment', 'gpu', 'optimization'],
        'Product Manager': ['roadmap', 'stakeholder', 'requirements', 'kpi', 'user research', 'go-to-market', 'strategy', 'prioritize', 'backlog', 'analytics'],
        'DevOps Engineer': ['ci', 'cd', 'kubernetes', 'docker', 'terraform', 'monitoring', 'aws', 'gcp', 'azure', 'prometheus', 'grafana']
    }
    text = (raw_text or "").lower()
    keywords = role_keywords.get(role or "", [])
    score = 0.0
    present = []
    for k in keywords:
        if k in text:
            present.append(k)
            score += 100.0 / max(1, len(keywords))
    score = int(min(100, round(score)))

    missing = [k for k in keywords if k not in present]
    suggestions = ats_suggestions_for(text)
    if missing:
        suggestions.insert(0, f"Consider adding: {', '.join(missing[:6])}")

    highlights = []
    if present:
        highlights.append(f"Tailored summary for {role} role:")
        highlights.append(f"- Demonstrated experience with {', '.join(present[:6])}.")
        highlights.append("- Quantified outcomes: improved performance, reduced costs, or accelerated delivery.")
        highlights.append("- Collaborated cross-functionally and upheld best practices (testing, code review).")
    else:
        highlights.append(f"Craft a role-aligned summary emphasizing transferable skills for {role or 'the role'}.")

    # Basic keyword extraction (top frequent words excluding stopwords)
    import re
    tokens = re.findall(r"[A-Za-z][A-Za-z+\-#\.]*", raw_text or "")
    stop = set("the a an and or of in on at to for with from by as is are was were be been being this that those these your you we our their they he she it my professional summary objective skills experience education projects certifications contact email phone github linkedin www http https com".split())
    freq = {}
    for t in tokens:
        k = t.lower()
        if k in stop or len(k) < 2:
            continue
        freq[k] = freq.get(k, 0) + 1
    keywords = sorted(freq.items(), key=lambda x: x[1], reverse=True)[:12]
    keywords = [k for k, _ in keywords]

    # Strengths and gaps based on role keywords
    strengths = [f"Mentions '{k}'" for k in present[:6]] or ["Relevant fundamentals present"]
    gaps = [f"Missing '{m}'" for m in missing[:6]] or []

    improvements = []
    if gaps:
        improvements.append("Address skill gaps by adding concrete examples or coursework.")
    if len(raw_text or "") < 1200:
        improvements.append("Increase resume depth to ~1–2 pages with quantified impact.")
    if "%" not in raw_text:
        improvements.append("Add measurable outcomes (e.g., 30% latency reduction, $200k cost savings).")
    if not any(h in (raw_text or "").lower() for h in ["lead", "mentor", "own", "drive", "impact"]):
        improvements.append("Include leadership or ownership signals.")

    alignment = "Strong alignment" if score >= 70 else ("Moderate alignment" if score >= 40 else "Low alignment")
    summary = (
        f"For the {role or 'target'} role, the resume shows {alignment.lower()} based on keyword coverage. "
        f"Key strengths include {', '.join(present[:3]) or 'general fundamentals'}."
    )

    return {
        "fitScore": score,
        "atsSuggestions": suggestions,
        "highlights": highlights,
        "detailed": {
            "summary": summary,
            "strengths": strengths,
            "gaps": gaps,
            "improvements": improvements,
            "alignment": alignment,
            "keywords": keywords,
        },
    }


@app.post("/api/parse")
def api_parse():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    f = request.files["file"]
    filename = f.filename or ""
    ext = os.path.splitext(filename)[1].lower()
    buf = io.BytesIO(f.read())
    text = ""
    if ext == ".txt":
        text = read_txt(buf)
    elif ext == ".pdf":
        text = read_pdf(buf)
    elif ext == ".docx":
        text = read_docx(buf)
    else:
        return jsonify({"error": f"Unsupported file type: {ext}"}), 400

    return jsonify({
        "rawText": text,
        "atsSuggestions": ats_suggestions_for(text),
        "briefSummary": summarize_brief(text),
    })


@app.post("/api/analyze")
def api_analyze():
    try:
        data = request.get_json(force=True)
    except Exception:
        data = {}
    raw_text = data.get("rawText") or ""
    role = data.get("role") or ""
    # linkedinUrl is ignored in this prototype
    result = analyze_locally(raw_text, role)
    return jsonify(result)


@app.post("/api/github-link")
def api_github_link():
    try:
        data = request.get_json(force=True)
    except Exception:
        data = {}
    url = (data.get("url") or "").strip()
    if not url:
        return jsonify({"error": "URL required"}), 400
    # In a real app, persist it in DB. Here we just echo back.
    return jsonify({"message": "GitHub link saved", "url": url})


@app.get("/health")
def health():
    return jsonify({"ok": True})


if __name__ == "__main__":
    # Use 0.0.0.0 for LAN access if needed
    app.run(host="127.0.0.1", port=5000, debug=True)


