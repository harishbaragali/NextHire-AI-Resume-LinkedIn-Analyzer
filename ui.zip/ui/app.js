(function(){
  const byId = (id) => document.getElementById(id);

  const fileInput = byId('resumeFile');
  const linkedinUrl = byId('linkedinUrl');
  const jobRole = byId('jobRole');
  const btnParse = byId('btnParse');
  const btnAnalyze = byId('btnAnalyze');
  const btnSample = byId('btnSample');
  const rawText = byId('rawText');
  const fitScore = byId('fitScore');
  const atsSuggestions = byId('atsSuggestions');
  const aiHighlights = byId('aiHighlights');
  const githubLink = byId('githubLink');
  const btnSaveLink = byId('btnSaveLink');
  const githubStatus = byId('githubStatus');
  const apiBaseInput = byId('apiBase');
  const btnSaveApi = byId('btnSaveApi');
  const forceServerChk = byId('forceServer');
  const diagnostics = byId('diagnostics');
  const year = byId('year');
  const dropzone = byId('dropzone');
  const toasts = byId('toasts');
  const gauge = byId('gauge');
  const gaugeText = byId('gaugeText');
  const briefSummary = byId('briefSummary');
  const detailSummary = byId('detailSummary');
  const detailStrengths = byId('detailStrengths');
  const detailGaps = byId('detailGaps');
  const detailImprovements = byId('detailImprovements');
  const detailAlignment = byId('detailAlignment');
  const detailKeywords = byId('detailKeywords');
  const btnCopyBrief = byId('btnCopyBrief');
  const btnCopyHighlights = byId('btnCopyHighlights');
  const btnCopyDetailed = byId('btnCopyDetailed');
  const btnExport = byId('btnExport');
  const historyList = byId('historyList');
  const btnClearHistory = byId('btnClearHistory');
  const spinnerResults = byId('spinnerResults');
  year.textContent = new Date().getFullYear();

  let selectedFile = null;
  const ng = window.angular && angular.element(document.body).scope && angular.element(document.body).scope();
  const vm = ng && ng.vm;

  function showToast(message, type){
    if(!toasts) return;
    const el = document.createElement('div');
    el.className = `toast ${type||''} fade-in`.trim();
    el.textContent = message;
    toasts.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 300);
    }, 2500);
  }

  function setDiagnostics(text){
    if(diagnostics){ diagnostics.textContent = text || ''; }
  }

  function setLoading(el, isLoading){
    if(!el) return;
    if(isLoading){
      el.dataset.originalText = el.textContent;
      el.textContent = 'Working…';
      el.classList.add('is-loading');
      el.disabled = true;
    }else{
      el.textContent = el.dataset.originalText || el.textContent;
      el.classList.remove('is-loading');
      el.disabled = false;
    }
  }

  function getSettings(){
    try{
      const s = JSON.parse(localStorage.getItem('nextHireSettings')||'null') || {};
      return { apiBase: s.apiBase || '', forceServer: true };
    }catch{ return { apiBase:'', forceServer:true }; }
  }

  function saveSettings(partial){
    const cur = getSettings();
    const next = { ...cur, ...partial, forceServer: true };
    try{ localStorage.setItem('nextHireSettings', JSON.stringify(next)); }catch{}
    if(apiBaseInput) apiBaseInput.value = next.apiBase || '';
    if(forceServerChk) forceServerChk.checked = true;
  }

  function saveState(){
    const state = {
      linkedinUrl: linkedinUrl?.value || '',
      jobRole: jobRole?.value || '',
      rawText: rawText?.value || '',
      githubLink: githubLink?.value || ''
    };
    try{ localStorage.setItem('nextHireState', JSON.stringify(state)); }catch{ /* ignore */ }
  }

  function restoreState(){
    try{
      const s = JSON.parse(localStorage.getItem('nextHireState')||'null');
      if(!s) return;
      if(linkedinUrl) linkedinUrl.value = s.linkedinUrl || '';
      if(jobRole) jobRole.value = s.jobRole || '';
      if(rawText) rawText.value = s.rawText || '';
      if(githubLink) githubLink.value = s.githubLink || '';
    }catch{ /* ignore */ }
  }

  function hydrateSettingsUI(){
    const s = getSettings();
    if(apiBaseInput) apiBaseInput.value = s.apiBase || '';
    if(forceServerChk){ forceServerChk.checked = true; forceServerChk.disabled = true; }
  }

  function updateGauge(percent){
    if(!gauge) return;
    const circleLength = 2 * Math.PI * 54; // r=54
    const clamped = Math.max(0, Math.min(100, Number(percent)||0));
    const offset = circleLength * (1 - clamped/100);
    const fill = gauge.querySelector('.gauge-fill');
    if(fill){ fill.style.strokeDasharray = `${circleLength}`; fill.style.strokeDashoffset = `${offset}`; }
    if(gaugeText){ gaugeText.textContent = clamped ? `${Math.round(clamped)}%` : '—'; }
    fitScore.textContent = clamped ? `${Math.round(clamped)}%` : '—';
    if(vm){ vm.fitScoreText = gaugeText.textContent; try{ angular.element(document.body).scope().$applyAsync(); }catch{} }
    fitScore.classList.add('pulse');
    setTimeout(() => fitScore.classList.remove('pulse'), 650);
  }

  async function callApi(path, options){
    const { apiBase } = getSettings();
    if(!apiBase){
      throw new Error('API base URL is not set. Enter it in Settings.');
    }
    const url = (apiBase || '') + path;
    const res = await fetch(url, options);
    if(!res.ok){
      const body = await res.text().catch(()=> '');
      const msg = `API ${path} failed: ${res.status} ${res.statusText} ${body ? '- ' + body.slice(0,200) : ''}`;
      throw new Error(msg);
    }
    return res.json();
  }

  function showSuggestions(items){
    atsSuggestions.innerHTML = '';
    (items || []).forEach(text => {
      const li = document.createElement('li');
      li.textContent = text;
      atsSuggestions.appendChild(li);
    });
    if(vm){ vm.atsSuggestions = items || []; try{ angular.element(document.body).scope().$applyAsync(); }catch{} }
  }

  function updateDetailedAnalysis(detailed){
    if(!detailed) return;
    
    // Update summary
    if(detailSummary) {
      detailSummary.textContent = detailed.summary || '';
      detailSummary.classList.remove('skeleton');
    }
    
    // Update strengths
    if(detailStrengths) {
      detailStrengths.innerHTML = '';
      (detailed.strengths || []).forEach(strength => {
        const li = document.createElement('li');
        li.textContent = strength;
        detailStrengths.appendChild(li);
      });
    }
    
    // Update gaps
    if(detailGaps) {
      detailGaps.innerHTML = '';
      (detailed.gaps || []).forEach(gap => {
        const li = document.createElement('li');
        li.textContent = gap;
        detailGaps.appendChild(li);
      });
    }
    
    // Update improvements
    if(detailImprovements) {
      detailImprovements.innerHTML = '';
      (detailed.improvements || []).forEach(improvement => {
        const li = document.createElement('li');
        li.textContent = improvement;
        detailImprovements.appendChild(li);
      });
    }
    
    // Update alignment
    if(detailAlignment) {
      detailAlignment.textContent = detailed.alignment || '';
      detailAlignment.classList.remove('skeleton');
    }
    
    // Update keywords
    if(detailKeywords) {
      detailKeywords.textContent = (detailed.keywords || []).join(', ');
      detailKeywords.classList.remove('skeleton');
    }
    
    // Update Angular scope
    if(vm){ 
      vm.detailed = detailed; 
      try{ angular.element(document.body).scope().$applyAsync(); }catch{} 
    }
  }

  function addToHistory(entry){
    try{
      const history = JSON.parse(localStorage.getItem('nextHireHistory') || '[]');
      history.unshift({
        ...entry,
        timestamp: new Date().toISOString(),
        id: Date.now()
      });
      if(history.length > 10) history.splice(10);
      localStorage.setItem('nextHireHistory', JSON.stringify(history));
      updateHistoryDisplay();
    }catch{}
  }

  function updateHistoryDisplay(){
    try{
      const history = JSON.parse(localStorage.getItem('nextHireHistory') || '[]');
      if(historyList){
        historyList.innerHTML = '';
        history.forEach(entry => {
          const li = document.createElement('li');
          li.innerHTML = `
            <div style="display:flex;justify-content:space-between;align-items:center">
              <span>${entry.role || 'Unknown Role'} - ${entry.score || 0}%</span>
              <small style="color:var(--muted)">${new Date(entry.timestamp).toLocaleString()}</small>
            </div>
          `;
          historyList.appendChild(li);
        });
      }
    }catch{}
  }

  function copyToClipboard(text, button){
    if(!text) return;
    navigator.clipboard.writeText(text).then(() => {
      showToast('Copied to clipboard', 'success');
      if(button){
        const original = button.textContent;
        button.textContent = 'Copied!';
        setTimeout(() => button.textContent = original, 2000);
      }
    }).catch(() => {
      showToast('Copy failed', 'error');
    });
  }

  function exportResults(){
    const data = {
      briefSummary: briefSummary?.textContent || '',
      fitScore: vm?.fitScoreText || '—',
      atsSuggestions: vm?.atsSuggestions || [],
      highlights: vm?.highlightsJoined || '',
      detailed: vm?.detailed || {},
      timestamp: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nexthire-analysis-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Results exported', 'success');
  }

  async function parseFileLocally(){ throw new Error('Offline parsing disabled.'); }
  function analyzeLocally(){ throw new Error('Offline analysis disabled.'); }

  if(dropzone){
    const onBrowse = () => fileInput?.click();
    dropzone.addEventListener('click', onBrowse);
    dropzone.addEventListener('dragover', (e) => { e.preventDefault(); dropzone.classList.add('dragover'); });
    dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzone.classList.remove('dragover');
      const dt = e.dataTransfer;
      if(dt && dt.files && dt.files[0]){
        selectedFile = dt.files[0];
        try{ fileInput.files = dt.files; }catch{}
        showToast(`Selected: ${selectedFile.name}`, 'success');
      }
    });
  }

  if(fileInput){
    fileInput.addEventListener('change', () => {
      if(fileInput.files && fileInput.files[0]){
        selectedFile = fileInput.files[0];
        showToast(`Selected: ${selectedFile.name}`, 'success');
      }
    });
  }

  if(btnSample){
    btnSample.addEventListener('click', () => {
      const sample = `Jane Doe\nSenior Software Engineer\n\nExperience\n- Led React + Node migration, improving TTFB by 35% and Lighthouse scores to 95+.\n- Built CI/CD with GitHub Actions and Terraform, reducing deploy time by 70%.\n- Implemented data pipelines with Airflow and Snowflake, ensuring 99.9% reliability.\n\nSkills\nJavaScript, TypeScript, React, Node.js, Express, PostgreSQL, Redis, Kubernetes, Docker, AWS, Terraform, Cypress, Jest, Grafana, Prometheus`;
      rawText.value = sample;
      showToast('Loaded sample resume text', 'success');
      saveState();
    });
  }

  btnParse.addEventListener('click', async () => {
    setDiagnostics('');
    try{
      const file = selectedFile || (fileInput.files && fileInput.files[0]);
      if(!file){
        alert('Please select a resume file.');
        return;
      }
      setLoading(btnParse, true);
      const form = new FormData();
      form.append('file', file);
      const data = await callApi('/api/parse', { method:'POST', body: form });
      showToast('Parsed via server', 'success');
      rawText.value = data.rawText || '';
      showSuggestions(data.atsSuggestions || []);
      if(briefSummary) {
        briefSummary.textContent = data.briefSummary || '';
        briefSummary.classList.remove('skeleton');
      }
      if(vm){ vm.briefSummary = data.briefSummary || ''; try{ angular.element(document.body).scope().$applyAsync(); }catch{} }
      saveState();
    }catch(err){
      console.error(err);
      setDiagnostics(err.message || String(err));
      showToast('Parsing failed (server)', 'error');
      alert('Parsing failed. Check diagnostics at the bottom.');
    }finally{
      setLoading(btnParse, false);
    }
  });

  btnAnalyze.addEventListener('click', async () => {
    setDiagnostics('');
    try{
      setLoading(btnAnalyze, true);
      if(spinnerResults) spinnerResults.classList.remove('d-none');
      
      const payload = {
        linkedinUrl: linkedinUrl.value.trim() || null,
        role: jobRole.value || null,
        rawText: rawText.value || null
      };
      const data = await callApi('/api/analyze', {
        method:'POST',
        headers: { 'Content-Type':'application/json' },
        body: JSON.stringify(payload)
      });
      showToast('Analyzed via server', 'success');
      updateGauge(data.fitScore != null ? data.fitScore : 0);
      showSuggestions(data.atsSuggestions || []);
      const highlightsJoined = (data.highlights || []).join('\n\n');
      aiHighlights.textContent = highlightsJoined;
      
      // Update detailed analysis
      updateDetailedAnalysis(data.detailed);
      
      if(vm){
        vm.highlightsJoined = highlightsJoined;
        vm.fitScoreText = data.fitScore != null ? `${Math.round(data.fitScore)}%` : '—';
        vm.detailed = data.detailed || vm.detailed;
        try{ angular.element(document.body).scope().$applyAsync(); }catch{}
      }
      
      // Add to history
      addToHistory({
        role: jobRole.value || 'Unknown Role',
        score: data.fitScore || 0,
        summary: data.detailed?.summary || ''
      });
      
      // Animate panels
      [aiHighlights, atsSuggestions, document.querySelector('.metric-gauge')].forEach(el => { 
        if(el){ 
          el.classList.add('slide-up'); 
          setTimeout(()=> el.classList.remove('slide-up'), 350);
        } 
      });
      
      // Animate detailed analysis sections
      [detailSummary, detailStrengths, detailGaps, detailImprovements, detailAlignment, detailKeywords].forEach(el => {
        if(el) {
          el.classList.add('slide-up');
          setTimeout(() => el.classList.remove('slide-up'), 350);
        }
      });
      
      saveState();
    }catch(err){
      console.error(err);
      setDiagnostics(err.message || String(err));
      showToast('Analysis failed (server)', 'error');
      alert('Analysis failed. Check diagnostics at the bottom.');
    }finally{
      setLoading(btnAnalyze, false);
      if(spinnerResults) spinnerResults.classList.add('d-none');
    }
  });

  btnSaveLink.addEventListener('click', async () => {
    const url = githubLink.value.trim();
    if(!url){
      githubStatus.textContent = 'Please enter a repository URL.';
      return;
    }
    try{
      const data = await callApi('/api/github-link', {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify({ url })
      });
      githubStatus.textContent = data.message || 'Saved.';
      showToast('GitHub link saved', 'success');
    }catch(err){
      console.error(err);
      githubStatus.textContent = 'Failed to save link.';
      setDiagnostics(err.message || String(err));
      showToast('GitHub link failed (server)', 'error');
    }
  });

  if(btnSaveApi && apiBaseInput){
    btnSaveApi.addEventListener('click', () => {
      saveSettings({ apiBase: apiBaseInput.value.trim() });
      showToast('API base saved', 'success');
    });
  }
  if(forceServerChk){
    forceServerChk.addEventListener('change', () => {
      saveSettings({ forceServer: true });
    });
  }

  // Copy button event listeners
  if(btnCopyBrief) {
    btnCopyBrief.addEventListener('click', () => {
      copyToClipboard(briefSummary?.textContent || '', btnCopyBrief);
    });
  }
  
  if(btnCopyHighlights) {
    btnCopyHighlights.addEventListener('click', () => {
      copyToClipboard(aiHighlights?.textContent || '', btnCopyHighlights);
    });
  }
  
  if(btnCopyDetailed) {
    btnCopyDetailed.addEventListener('click', () => {
      const detailedText = `
Summary: ${detailSummary?.textContent || ''}

Strengths:
${Array.from(detailStrengths?.children || []).map(li => `• ${li.textContent}`).join('\n')}

Gaps:
${Array.from(detailGaps?.children || []).map(li => `• ${li.textContent}`).join('\n')}

Improvements:
${Array.from(detailImprovements?.children || []).map(li => `• ${li.textContent}`).join('\n')}

Alignment: ${detailAlignment?.textContent || ''}

Keywords: ${detailKeywords?.textContent || ''}
      `.trim();
      copyToClipboard(detailedText, btnCopyDetailed);
    });
  }
  
  if(btnExport) {
    btnExport.addEventListener('click', exportResults);
  }
  
  if(btnClearHistory) {
    btnClearHistory.addEventListener('click', () => {
      localStorage.removeItem('nextHireHistory');
      updateHistoryDisplay();
      showToast('History cleared', 'success');
    });
  }

  [linkedinUrl, jobRole, rawText, githubLink].forEach(el => el && el.addEventListener('input', saveState));

  updateGauge(0);
  restoreState();
  hydrateSettingsUI();
  updateHistoryDisplay();
})();


